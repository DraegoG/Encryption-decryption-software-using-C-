#include<iostream>
#include<fstream>
using namespace std;

    ifstream fin;
    ofstream fout;
    int b=0,i=0;
    int key1(),key2(),key3(),key4(),key5(),key6();
    char ch=NULL;

int main()
{
    fin.open("Encrypted.txt");
    fout.open("Decrypted.txt");
    ch=fin.get();
    if(ch=='1')      key1();
    else if(ch=='2') key2();
    else if(ch=='3') key3();
    else if(ch=='4') key4();
    else if(ch=='5') key5();
    else if(ch=='6') key6();
    fin.close();
    fout.close();
}

int key1()
{
        ch=fin.get();
        int a[10]={2,5,1,3,6,4,8,11,9,7};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch - a[i] + 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key2()
{
        ch=fin.get();
        int a[10]={5,6,8,1,2,4,6,7,9,3};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch - a[i] + 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key3()
{
        ch=fin.get();
        int a[10]={8,9,6,3,2,1,4,5,6,7};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch - a[i] +60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key4()
{
        ch=fin.get();
        int a[10]={9,6,4,7,5,1,2,3,0,1};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch - a[i] +60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key5()
{
        ch=fin.get();
        int a[10]={13,6,15,4,8,9,11,2,12,10};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch - a[i] +60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key6()
{
        ch=fin.get();
        int a[10]={4,7,8,9,1,0,11,10,6,13};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch - a[i] +60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}
