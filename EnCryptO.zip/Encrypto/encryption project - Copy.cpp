#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<conio.h>
#include<string.h>
using namespace std;

    ifstream fin;
    ofstream fout;
    int b=0,i=0,n;
    int key1(),key2(),key3(),key4(),key5(),key6();
    char ch=NULL;

int main()
{
    //string s1="project",s2;
    char str1[] = "project";
    char str2[7] ;
    cin>>str2;
    if (strcmp(str1, str2) == 0)
        cout << "Equal" << endl;
    else
        cout << "Not equal" << endl;

    int a=1,b=0; //s1.size();
    char c='y';
    cout<<"Enter the password: ";
    while(c='y')
    {
     //while(a--)
	 //{
		//if(getch()) cout<<"*";
		//cin>>s2;
	 //}
//cout<<"this: "<<s1<<endl<<s2;
  //   if(strcmp(s1,s2)!=0)
	 {
		cout<<endl<<"Wrong password!!"<<endl<<"Do you want to try again?  y or n :";
		cin>>ch;
		if(c=='n') exit(0);
 	 }
    }
    fin.open("ToEncrypt.txt");
    fout.open("Encrypted.txt");
    cout<<"Enter the no. of encryption key: ";  cin>>n;
    switch(n)
    {
    case 1:
        key1(); break;
    case 2:
        key2(); break;
    case 3:
        key3(); break;
    case 4:
        key4(); break;
    case 5:
        key5(); break;
    case 6:
        key6(); break;
    default:
        key1(); break;
    }
    fin.close();
    fout.close();
}
int key1()
{
        fout<<"1"<<endl;
        int a[10]={2,5,1,3,6,4,8,11,9,7};    //char cn='a'; int bn=cn; cout<<bn<<endl;
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch + a[i] - 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key2()
{
        fout<<"2"<<endl;
        int a[10]={5,6,8,1,2,4,6,7,9,3};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch + a[i] - 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key3()
{
        fout<<"3"<<endl;
        int a[10]={8,9,6,3,2,1,4,5,6,7};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch + a[i] - 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key4()
{
        fout<<"4"<<endl;
        int a[10]={9,6,4,7,5,1,2,3,0,1};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch + a[i] - 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key5()
{
        fout<<"5"<<endl;
        int a[10]={13,6,15,4,8,9,11,2,12,10};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch + a[i] - 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}

int key6()
{
        fout<<"6"<<endl;
        int a[10]={4,7,8,9,1,0,11,10,6,13};
        ch=fin.get();
        while(!fin.eof())
        {
            b=(int)ch + a[i] - 60;
            fout<<(char)b;
            ch=fin.get();
            i++;
            if(i==10) i=0;
        }
}
